<h1 align="center">Commodus Cafe ☕</h1>

![Screenshot (667)](https://github.com/sntdshrly/company-profile-cafe/assets/71547739/59c1586f-c2d9-4faa-86ef-994a83aeee4a)

You may open it on your browser: https://commoduscafe.netlify.app/

## Project Teams
- Sherly Santiadi
- Nisa Deviani

## Thank You
